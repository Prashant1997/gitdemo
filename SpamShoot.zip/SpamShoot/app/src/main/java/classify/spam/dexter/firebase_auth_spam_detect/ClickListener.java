package classify.spam.dexter.firebase_auth_spam_detect;

import android.content.Context;
import android.view.View;

/**
 * Created by Prashant on 11-10-2017.
 */

public interface ClickListener {
    public void itemClicked(View view, int position);
}